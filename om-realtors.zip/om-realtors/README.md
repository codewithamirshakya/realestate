# Om Realtors &mdash; Real Estate Platform

A full-featured real estate marketplace built with Laravel, created for **Om Realtors Pvt. Ltd.**
(ओम रियलटर्स प्रा. लि.), Batukbhairab, Hanumansthan, Lagankhel, Lalitpur.

## What's included

- **Public site** &mdash; home page, property listings with search/filter (type, category, city,
  price, bedrooms), property detail pages with an inquiry form, a services page built from the
  six services on the company's business card, an about page, and a contact form that emails
  the team and logs the message.
- **Accounts & roles** &mdash; visitors can register as a **buyer** (browse, save favorites, send
  inquiries) or an **agent** (list and manage their own properties). An **admin** role manages
  everything.
- **Agent dashboard** &mdash; create/edit/delete listings, upload multiple photos per property,
  mark a listing sold/rented/pending, see inquiries received.
- **Admin dashboard** &mdash; manage every property (assign to any agent), manage inquiries
  (status: new/contacted/closed), manage users and their roles, and edit the services shown on
  the Services page.
- **Buyer dashboard** &mdash; saved/favorited properties and a history of inquiries sent.
- Branding, colors, and copy are based on the Om Realtors business card (navy `#1c4f6e` and
  green `#4bb95a`), with an inline SVG recreation of the mountain/skyline logo mark so it stays
  crisp at any size, plus bilingual (Nepali/English) labels throughout.

## Tech stack

- Laravel 13 (PHP 8.3+)
- SQLite by default (zero setup) &mdash; swap to MySQL/Postgres by editing `.env`
- Tailwind CSS v4 + Vite for the frontend build
- Laravel's built-in session auth (no separate auth package) with a custom `role` middleware for
  admin/agent/buyer access control

## ⚠️ About this build

This project was scaffolded in a sandboxed environment whose network access does not include
**Packagist** (Composer's package registry), so `composer install` could not be run or verified
here. Every PHP file has been checked with `php -l` (no syntax errors), and the Tailwind/Vite
frontend build was test-compiled successfully. On your own machine &mdash; which has normal
internet access &mdash; `composer install` will work exactly as it would for any fresh Laravel
project. Follow the setup steps below.

## Setup

1. **Install PHP dependencies**

   ```bash
   composer install
   ```

2. **Copy the environment file and generate an app key**

   The `.env` file is already included with sensible local defaults (SQLite, mail logged instead
   of sent). If you'd rather start fresh:

   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

   If you're using the included `.env`, just run `php artisan key:generate` if `APP_KEY` is empty.

3. **Create the SQLite database** (already created as an empty file at
   `database/database.sqlite`; skip if it already exists)

   ```bash
   touch database/database.sqlite
   ```

4. **Run migrations and seed demo data**

   ```bash
   php artisan migrate --seed
   ```

   This creates:

   | Role  | Email                     | Password   |
   |-------|---------------------------|------------|
   | Admin | admin@omrealtors.com.np   | password   |
   | Agent | agent@omrealtors.com.np   | password   |
   | Buyer | buyer@example.com         | password   |

   plus 3 extra demo agents and 24 sample property listings with placeholder photos, and the
   six services from the business card.

   **Change these passwords before deploying anywhere public.**

5. **Link storage** (so uploaded/seeded property photos are servable)

   ```bash
   php artisan storage:link
   ```

6. **Install JS dependencies and build the frontend**

   ```bash
   npm install
   npm run build
   ```

   For local development with hot reload, use `npm run dev` in a second terminal instead.

7. **Serve the app**

   ```bash
   php artisan serve
   ```

   Visit http://localhost:8000.

### One-liner (after `composer install` and `npm install`)

```bash
php artisan key:generate && php artisan migrate --seed && php artisan storage:link && npm run build
```

## Things to update before going live

- **`config/company.php`** (and the matching `COMPANY_*` values in `.env`) &mdash; the phone
  number was not fully legible on the photographed business card, so it's currently a
  placeholder (`+977-98XXXXXXXX`). Update it, plus the email and Facebook link.
- **Mail** &mdash; `.env` currently uses `MAIL_MAILER=log`, so contact-form emails are written to
  `storage/logs/laravel.log` instead of actually being sent. Point `MAIL_*` at a real SMTP
  provider (or Mailgun/SES/etc.) before launch.
- **Database** &mdash; SQLite is fine for development; for production, switch `DB_CONNECTION` in
  `.env` to `mysql` or `pgsql` and fill in the connection details.
- **Seeded demo data** &mdash; the 24 sample properties and demo users are for development only.
  Remove them (or just don't run `--seed` in production) and replace the placeholder property
  photos with real listing photos.
- **Storage disk** &mdash; property photos are stored on the `public` local disk
  (`storage/app/public`). For production on more than one server, switch to an S3-compatible
  disk in `config/filesystems.php`.

## Project structure notes

- `app/Http/Controllers/Agent/*` and `app/Http/Controllers/Admin/*` both manage properties;
  shared upload/delete logic lives in `app/Http/Controllers/Concerns/ManagesPropertyImages.php`.
- Role access is enforced by `app/Http/Middleware/EnsureUserHasRole.php`, registered as the
  `role` middleware alias in `bootstrap/app.php` (used as `->middleware('role:admin')` etc.).
- `resources/views/properties/_form.blade.php` is a shared create/edit form used by both the
  agent and admin property views.
- The logo mark is a generated inline SVG component at
  `resources/views/components/logo-mark.blade.php` (no image dependency, scales cleanly).
- The two original business card photos are included at
  `public/images/business-card-front.jpg` / `business-card-back.jpg` and shown on the About page.
