@extends('layouts.app')

@section('content')
<div class="bg-brand-800 py-14 text-center text-white">
    <h1 class="font-serif text-3xl font-bold sm:text-4xl">हाम्रा सेवाहरू &mdash; Our Services</h1>
    <p class="mt-2 text-brand-200">Complete support for buying, selling, and managing property in Nepal</p>
</div>

<div class="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
    <div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        @foreach ($services as $service)
            <div class="card p-7">
                <div class="flex h-12 w-12 items-center justify-center rounded-lg bg-brand-600 text-white">
                    <x-service-icon :icon="$service->icon" class="h-6 w-6" />
                </div>
                <h2 class="mt-4 text-lg font-bold text-brand-800">{{ $service->title_en }}</h2>
                <p class="text-sm font-medium text-brand-400">{{ $service->title_np }}</p>
                <p class="mt-3 text-sm leading-relaxed text-brand-600">{{ $service->description_en }}</p>
                @if ($service->description_np)
                    <p class="mt-2 text-sm leading-relaxed text-brand-400">{{ $service->description_np }}</p>
                @endif
            </div>
        @endforeach
    </div>

    <div class="card mt-14 flex flex-col items-center gap-4 bg-accent-50/60 p-10 text-center">
        <h2 class="font-serif text-2xl font-bold text-brand-800">Need help with a service?</h2>
        <p class="max-w-xl text-brand-500">Reach out to our team &mdash; {{ config('company.contact_person') }} and our staff are ready to assist you in Nepali or English.</p>
        <a href="{{ route('contact.create') }}" class="btn-primary">Contact Us</a>
    </div>
</div>
@endsection
