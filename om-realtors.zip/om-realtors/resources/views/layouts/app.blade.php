<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? config('company.name_en') }} | {{ config('company.name_en') }}</title>
    <meta name="description" content="{{ $description ?? config('company.tagline_en') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @fonts

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="flex min-h-screen flex-col bg-white text-brand-900 font-sans">

    @include('partials.nav')

    @include('partials.flash-messages')

    <main class="flex-1">
        @yield('content')
    </main>

    @include('partials.footer')

</body>
</html>
