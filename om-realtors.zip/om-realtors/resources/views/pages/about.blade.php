@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
    <div class="grid items-center gap-12 lg:grid-cols-2">
        <div>
            <span class="badge bg-accent-50 text-accent-600">About Us</span>
            <h1 class="mt-4 font-serif text-3xl font-bold text-brand-900 sm:text-4xl">{{ config('company.name_en') }}</h1>
            <p class="mt-1 text-lg text-brand-400">{{ config('company.name_np') }}</p>

            <p class="mt-6 leading-relaxed text-brand-600">
                {{ config('company.name_en') }} is a real estate services company based in
                {{ config('company.address_en') }}. We help buyers, sellers, and investors navigate
                every step of a property transaction &mdash; from accounting and land surveys to plotting,
                loans, map design, and buying or selling homes and land across the Kathmandu Valley.
            </p>
            <p class="mt-4 leading-relaxed text-brand-500">
                हामी ग्राहकहरूलाई घर जग्गा किनबेच, जग्गा नापजाँच, प्लटिङ्ग, ऋण सेवा र नक्सा डिजाइनमा
                विश्वसनीय र पारदर्शी सेवा प्रदान गर्दछौं।
            </p>

            <div class="mt-8 grid grid-cols-2 gap-6">
                <div>
                    <p class="text-3xl font-bold text-brand-700">{{ $stats['properties'] }}+</p>
                    <p class="text-sm text-brand-400">Properties handled</p>
                </div>
                <div>
                    <p class="text-3xl font-bold text-brand-700">{{ $stats['sold'] }}+</p>
                    <p class="text-sm text-brand-400">Successful deals</p>
                </div>
            </div>

            <a href="{{ route('contact.create') }}" class="btn-primary mt-8 inline-flex">Get in touch</a>
        </div>

        <div class="flex flex-col items-center gap-6">
            <img src="{{ asset('images/business-card-front.jpg') }}" alt="{{ config('company.name_en') }} business card" class="w-full max-w-md rounded-xl border border-brand-100 shadow-md">
            <img src="{{ asset('images/business-card-back.jpg') }}" alt="{{ config('company.name_en') }} services card" class="w-full max-w-md rounded-xl border border-brand-100 shadow-md">
        </div>
    </div>

    <div class="mt-16 grid gap-6 border-t border-brand-100 pt-12 sm:grid-cols-3">
        <div class="card p-6">
            <h3 class="font-semibold text-brand-800">Our Office</h3>
            <p class="mt-2 text-sm text-brand-500">{{ config('company.address_en') }}</p>
            <p class="text-sm text-brand-400">{{ config('company.address_np') }}</p>
        </div>
        <div class="card p-6">
            <h3 class="font-semibold text-brand-800">Talk to Us</h3>
            <p class="mt-2 text-sm text-brand-500">{{ config('company.contact_person') }}</p>
            <p class="text-sm text-brand-500">{{ config('company.phone') }}</p>
        </div>
        <div class="card p-6">
            <h3 class="font-semibold text-brand-800">Email</h3>
            <p class="mt-2 text-sm text-brand-500">{{ config('company.email') }}</p>
        </div>
    </div>
</div>
@endsection
